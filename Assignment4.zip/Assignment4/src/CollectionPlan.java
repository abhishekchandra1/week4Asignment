public interface CollectionPlan {

    public IteratorPlan getIterator();
}