public interface IteratorPlan 
{
    public Boolean hasNext();
    public Object next();
}